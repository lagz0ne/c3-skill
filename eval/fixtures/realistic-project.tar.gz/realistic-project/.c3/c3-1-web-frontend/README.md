---
id: c3-1
c3-version: 3
title: Web Frontend
type: container
parent: c3-0
summary: React-based SPA for invoice management, payment requests, and approval workflows
---

# Web Frontend

The Web Frontend is a React single-page application built with TanStack Router and TanStack Start. It provides the user interface for employees to manage invoices, create payment requests, and process approvals. State management is handled via @pumped-fn/react-lite atoms with SSR-prefetched data.

## Overview

```mermaid
graph TD
    subgraph Foundation
        c3-101[Router]
        c3-102[AuthLayout]
        c3-103[State Atoms]
        c3-104[UI Variants]
    end

    subgraph Auxiliary
        c3-111[Form Patterns]
        c3-112[Data Sync]
        c3-113[Error Handling]
        c3-114[Design System]
        c3-115[Visual Specs]
    end

    subgraph Feature
        c3-121[Invoice Screen]
        c3-122[Payment Requests Screen]
        c3-123[Payments Screen]
        c3-124[Login Screen]
    end

    %% Foundation to Auxiliary
    c3-101 --> c3-102
    c3-102 --> c3-103
    c3-103 --> c3-112

    %% Auxiliary to Feature
    c3-111 --> c3-121
    c3-111 --> c3-122
    c3-112 --> c3-121
    c3-112 --> c3-122
    c3-112 --> c3-123
    c3-113 --> c3-121
    c3-113 --> c3-122

    %% Feature uses Foundation
    c3-104 --> c3-114
    c3-114 --> c3-115
    c3-114 --> c3-121
    c3-114 --> c3-122
    c3-114 --> c3-123
    c3-115 --> c3-133
```

## Components

### Foundation
> Primitives others build on. High impact when changed. Reusable within this container.

| ID | Name | Status | Responsibility |
|----|------|--------|----------------|
| c3-101 | Router | active | TanStack Router configuration, route tree, scroll restoration |
| c3-102 | AuthLayout | active | Authenticated layout wrapper, sidebar navigation, theme toggle, user menu |
| c3-103 | State Atoms | active | @pumped-fn/lite atoms for user, invoices, PRs, payments, approval flow state |
| c3-104 | UI Variants | active | tailwind-variants definitions for modal, alert, button, input, table styling |

### Auxiliary
> Conventions for using external tools HERE. "This is how we use X in this project."

| ID | Name | Status | Responsibility |
|----|------|--------|----------------|
| c3-111 | Form Patterns | active | Reusable form components (FormField, FormSelect, FormDatePicker), validation display |
| c3-112 | Data Sync | active | WebSocket-based real-time data synchronization, optimistic updates, delta handling |
| c3-113 | Error Handling | active | ErrorBoundary, ErrorDisplay, InitErrorDisplay for graceful error presentation |
| c3-114 | Design System | active | DaisyUI lofi theme, tailwind-variants, color tokens, typography, spacing conventions |
| c3-115 | Visual Specs | active | Typography scale, spacing tokens, pattern wireframes for consistent screen generation |

### Feature
> Domain-specific. Uses Foundation + Auxiliary. Not reusable outside this context.

| ID | Name | Status | Responsibility |
|----|------|--------|----------------|
| c3-121 | Invoice Screen | active | Invoice list with filtering, invoice detail drawer, status management |
| c3-122 | Payment Requests Screen | active | PR list, PR creation/editing, approval workflow UI, filter panel |
| c3-123 | Payments Screen | active | Payment tracking, completion status |
| c3-124 | Login Screen | active | Google OAuth login flow, redirect handling |

### Documentation
> UI documentation for screens, regions, and user flows.

| ID | Name | Status | Responsibility |
|----|------|--------|----------------|
| c3-131 | Information Architecture | active | Screen inventory with regions at medium abstraction level |
| c3-132 | User Flows | active | Exhaustive flow documentation with preconditions and dependencies |
| c3-133 | UI Patterns | active | Catalog of UI design patterns with implementation references |

## Fulfillment

| Link (from c3-0) | Fulfilled By | Constraints |
|------------------|--------------|-------------|
| A1 (Employee) -> c3-1 | c3-121, c3-122, c3-123 | Must be authenticated via c3-102 |
| A2 (Approver) -> c3-1 | c3-122 | PRs filtered by user role/team via c3-103 |
| c3-1 -> c3-2 | TanStack Server Functions | All data operations via createServerFn |

## Linkages

| From | To | Reasoning |
|------|-----|-----------|
| c3-101 | c3-102 | Router mounts AuthLayout for /_authed/* routes |
| c3-102 | c3-103 | AuthLayout initializes state atoms with SSR-prefetched data via ScopeProvider |
| c3-103 | c3-112 | State atoms subscribe to WebSocket sync for real-time updates |
| c3-111 | c3-121, c3-122 | Feature screens use shared form components for consistent UX |
| c3-104 | c3-114 | UI variants consumed by Design System conventions |
| c3-114 | All Screens | Design System provides consistent theming and component styling |
| c3-113 | c3-121, c3-122 | ErrorBoundary wraps feature screens to catch and display errors gracefully |

## Testing

> Tests component <-> component linkages within this container.

### Integration Tests

| Scenario | Components Involved | Verifies |
|----------|---------------------|----------|
| Auth redirect | c3-101, c3-102, c3-124 | Unauthenticated users redirect to login |
| Data loading | c3-102, c3-103 | SSR data populates state atoms correctly |
| Real-time sync | c3-103, c3-112 | WebSocket messages update UI state |
| Form submission | c3-111, c3-122 | PR forms validate and submit correctly |

### Mocking

| Dependency | How to Mock | When |
|------------|-------------|------|
| Server Functions | createServerFn mock | Unit testing feature screens |
| WebSocket | Mock WS server | Testing data sync behavior |
| Router | MemoryHistory | Component isolation tests |

### Fixtures

| Entity | Factory/Source | Notes |
|--------|----------------|-------|
| User | test/fixtures/user.ts | Includes permissions array |
| Invoice | test/fixtures/invoice.ts | ListInvoiceRow format |
| Payment Request | test/fixtures/pr.ts | ListPrRow format with approval state |
