---
id: c3-112
c3-version: 3
title: Data Sync
type: component
category: auxiliary
parent: c3-1
summary: Real-time data synchronization via WebSocket with delta updates and optimistic UI
---

# Data Sync

Establishes how real-time data updates flow from server to client using WebSocket connections, delta message processing, and optimistic update acknowledgment patterns.

## Conventions

| Rule | Why |
|------|-----|
| Connect WebSocket on authenticated user only | No sync for unauthenticated sessions |
| Process delta messages via applyDelta helper | Consistent merge of add/update/delete changesets |
| Track executionId for optimistic updates | Prevents duplicate UI updates when own action returns |
| Handle ack messages separately | Server confirms receipt, client can clear pending state |
| Cleanup connection on scope dispose | Prevents memory leaks and zombie connections |
| Use controller.update for atomic state changes | Ensures React re-renders correctly |

## Applies To

| Component | Usage |
|-----------|-------|
| c3-103 State Atoms | prs, invoices, payments atoms updated by sync |
| c3-122 Payment Requests Screen | Real-time PR status updates |
| c3-121 Invoice Screen | Invoice changes from other users |
| c3-123 Payments Screen | Payment completion notifications |

## Testing

| Convention | How to Test |
|------------|-------------|
| Delta processing | Send mock delta message, verify state updated |
| ExecutionId filtering | Send message with own executionId, verify no duplicate |
| Connection cleanup | Dispose scope, verify WebSocket closed |
| Reconnection | Simulate disconnect, verify auto-reconnect |
| Error handling | Send malformed message, verify logged not crashed |

## References

- `apps/start/src/lib/pumped/atoms/sync.ts` - Client sync atom
- `apps/start/src/server/resources/sync.ts` - Server sync types
