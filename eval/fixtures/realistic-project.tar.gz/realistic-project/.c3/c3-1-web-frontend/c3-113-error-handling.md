---
id: c3-113
c3-version: 3
title: Error Handling
type: component
category: auxiliary
parent: c3-1
summary: Conventions for catching, displaying, and recovering from errors in the UI
---

# Error Handling

Establishes how errors are caught and displayed using React ErrorBoundary with retry support, structured error display components, and consistent error messaging patterns.

## Conventions

| Rule | Why |
|------|-----|
| Wrap feature screens in ErrorBoundary | Prevents full app crash on component error |
| Use ErrorDisplay for user-facing errors | Consistent styling and messaging |
| Provide retry mechanism with maxRetries | Allows recovery from transient failures |
| Log errors to console in componentDidCatch | Debugging visibility in development |
| Pass onError callback for telemetry | Enables error tracking integration |
| Show fallback UI during error state | User understands something went wrong |
| InitErrorDisplay for SSR/hydration errors | Special handling for initial load failures |

## Applies To

| Component | Usage |
|-----------|-------|
| c3-102 AuthLayout | Wraps all authenticated routes |
| c3-121 Invoice Screen | Catches rendering errors |
| c3-122 Payment Requests Screen | Catches rendering errors |
| Server function calls | Displays API error responses |

## Testing

| Convention | How to Test |
|------------|-------------|
| Error catching | Throw in child component, verify boundary catches |
| Retry mechanism | Click retry, verify component re-mounts |
| Max retries limit | Exhaust retries, verify retry disabled |
| Error display | Trigger error, verify ErrorDisplay renders |
| onError callback | Trigger error, verify callback invoked with error |

## References

- `apps/start/src/components/Error*.tsx` - Error boundary and display components
