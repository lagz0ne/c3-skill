---
id: c3-115
c3-version: 3
title: Visual Specs
type: component
category: auxiliary
parent: c3-1
summary: Typography scale, spacing tokens, and visual wireframes for consistent screen generation
---

# Visual Specs

Documents the visual specifications needed to generate new screens with consistent appearance. Complements c3-114 Design System (definitions) and c3-133 UI Patterns (behaviors).

## Uses

| Category | Component | For |
|----------|-----------|-----|
| Auxiliary | c3-114 Design System | Token definitions this spec applies |
| Documentation | c3-133 UI Patterns | Pattern structures to wireframe |
| Foundation | c3-104 UI Variants | Variant size values |

## Typography Scale

| Token | Size | Weight | Line Height | Usage |
|-------|------|--------|-------------|-------|
| `text-lg` | 1.125rem (18px) | 600 | 1.75 | Page titles, drawer headers |
| `text-base` | 1rem (16px) | 400 | 1.5 | Body text, descriptions |
| `text-sm` | 0.875rem (14px) | 400 | 1.25 | List items, form labels |
| `text-xs` | 0.75rem (12px) | 400 | 1 | Badges, timestamps, amounts |
| `text-[0.7rem]` | 0.7rem (11.2px) | 700 | 1 | Section headers (uppercase) |
| `text-[0.65rem]` | 0.65rem (10.4px) | 500 | 1 | Meta labels (uppercase) |

### Font Families

| Variable | Font | Usage |
|----------|------|-------|
| `--font-display` | Inter Variable | All UI text |
| `--font-mono` | JetBrains Mono | Amounts, IDs, codes |
| `--font-logo` | Orbit | Logo only |

## Spacing Scale

| Token | Value | Usage |
|-------|-------|-------|
| `space-0.5` | 2px | Tight gaps (badge padding) |
| `space-1` | 4px | Icon gaps, inline spacing |
| `space-2` | 8px | List item gaps, small padding |
| `space-3` | 12px | Section padding, list padding |
| `space-4` | 16px | Card padding, detail sections |
| `space-6` | 24px | Drawer body padding |
| `space-8` | 32px | Large section gaps |

### Component Heights

| Component | Height | Class |
|-----------|--------|-------|
| Button xs | 28px | `h-7` |
| Button sm | 32px | `h-8` |
| Button md | 36px | `h-9` |
| Button lg | 40px | `h-10` |
| Input | 36px | `h-9` |
| Footer bar | 56px | `min-h-[3.5rem]` |

## Pattern Wireframes

### PTN-01 Master-Detail Layout

```
┌─────────────────────────────────────────────────────────────┐
│ GBL-SIDEBAR │           CONTENT AREA                        │
│   (hidden   │                                               │
│   mobile)   │  ┌──────────┐  ┌──────────────────────────┐  │
│             │  │ LIST     │  │ DETAIL PANEL             │  │
│             │  │ w-80     │  │ flex-1                   │  │
│             │  │          │  │                          │  │
│             │  │ ┌──────┐ │  │ ┌────────────────────┐   │  │
│             │  │ │HEADER│ │  │ │ PNL-*-HDR          │   │  │
│             │  │ │ p-3  │ │  │ │ p-3, border-b      │   │  │
│             │  │ └──────┘ │  │ └────────────────────┘   │  │
│             │  │          │  │                          │  │
│             │  │ ┌──────┐ │  │ ┌────────────────────┐   │  │
│             │  │ │ITEMS │ │  │ │ CONTENT            │   │  │
│             │  │ │ p-2  │ │  │ │ flex-1 overflow    │   │  │
│             │  │ │      │ │  │ │                    │   │  │
│             │  │ │ 3px  │ │  │ │ detail-section     │   │  │
│             │  │ │ left │ │  │ │ py-4 border-b      │   │  │
│             │  │ │border│ │  │ │                    │   │  │
│             │  │ └──────┘ │  │ └────────────────────┘   │  │
│             │  │          │  │                          │  │
│             │  │ ┌──────┐ │  │ ┌────────────────────┐   │  │
│             │  │ │FOOTER│ │  │ │ FOOTER             │   │  │
│             │  │ │h-14  │ │  │ │ footer-bar-detail  │   │  │
│             │  │ └──────┘ │  │ └────────────────────┘   │  │
│             │  └──────────┘  └──────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘

Mobile: LIST and DETAIL stack, slide transition 200ms
Breakpoint: 768px (md)
```

### PTN-03 Drawer (Side Sheet)

```
                              ┌─────────────────────┐
                              │ OVERLAY             │
                              │ bg-black/80         │
┌─────────────────────────────┼─────────────────────┤
│     (dimmed content)        │ DRAWER PANEL        │
│                             │ w-3/4 max-w-md      │
│                             │                     │
│                             │ ┌─────────────────┐ │
│                             │ │ HEADER          │ │
│                             │ │ p-6 border-b    │ │
│                             │ │                 │ │
│                             │ │ Title (text-lg) │ │
│                             │ │ [X] close btn   │ │
│                             │ └─────────────────┘ │
│                             │                     │
│                             │ ┌─────────────────┐ │
│                             │ │ BODY            │ │
│                             │ │ flex-1 p-6      │ │
│                             │ │ overflow-y-auto │ │
│                             │ │                 │ │
│                             │ │ (form fields)   │ │
│                             │ │                 │ │
│                             │ └─────────────────┘ │
│                             │                     │
│                             │ ┌─────────────────┐ │
│                             │ │ ACTIONS (sticky)│ │
│                             │ │ border-t p-6    │ │
│                             │ │ safe-area-inset │ │
│                             │ └─────────────────┘ │
│                             └─────────────────────┘
└─────────────────────────────┘

Animation: slide-in-from-right 500ms, slide-out 300ms
Width variants: sm (max-w-sm), md, lg, xl, full
```

## Status Badge Colors

| Status | Background | Text | Border | CSS Variable |
|--------|------------|------|--------|--------------|
| success | `bg-success/10` | `text-success` | `border-success/50` | `--success: 142 76% 36%` |
| warning | `bg-warning/10` | `text-warning` | `border-warning/50` | `--warning: 38 92% 50%` |
| error | `bg-destructive/10` | `text-destructive` | `border-destructive/50` | `--destructive: 0 84.2% 60.2%` |
| info | `bg-info/10` | `text-info` | `border-info/50` | `--info: 199 89% 48%` |
| neutral | `bg-muted` | `text-muted-foreground` | - | `--muted: 240 4.8% 95.9%` |

### List Item Status Borders

| Status | Left Border Color | Animation |
|--------|-------------------|-----------|
| inprogress | `--success` | `badge-pulse 2s` |
| imported | `--warning` | none |
| completed | `--info` | none |
| obsolete | `--destructive` | none |

## Detail Section Anatomy

```
┌─────────────────────────────────────────┐
│ ┌─ SECTION HEADER ────────────────────┐ │
│ │ [icon] SECTION TITLE                │ │  text-[0.7rem] uppercase
│ │        tracking-[0.08em]            │ │  font-weight-700
│ └─────────────────────────────────────┘ │
│                                         │
│ ┌─ META GRID ─────────────────────────┐ │
│ │ ┌───────────┬───────────┬─────────┐ │ │  grid, 1px gap
│ │ │ LABEL     │ LABEL     │ LABEL   │ │ │  text-[0.65rem] uppercase
│ │ │ Value     │ Value     │ Value   │ │ │  text-sm font-500
│ │ └───────────┴───────────┴─────────┘ │ │
│ └─────────────────────────────────────┘ │
│                                         │
│ border-b-2 border-border                │
└─────────────────────────────────────────┘
```

## Conventions

| Rule | Why |
|------|-----|
| Use typography tokens, not arbitrary sizes | Consistent hierarchy |
| Use spacing scale for padding/margins | Predictable rhythm |
| Match wireframe proportions | Visual consistency across screens |
| Apply status colors via semantic names | Theme-aware styling |

## Testing

| Scenario | Verifies |
|----------|----------|
| New screen matches typography scale | All text uses documented tokens |
| Spacing follows scale | No arbitrary values outside scale |
| Status colors applied correctly | Semantic names map to theme tokens |
| Wireframe proportions match | List width, panel flex ratios correct |

## References

- `apps/start/src/styles.css` - Token definitions
- `apps/start/src/components/ui/variants.ts` - Component variants
- `apps/start/src/components/MasterDetailLayout.tsx` - PTN-01 implementation
- `apps/start/src/components/Drawer.tsx` - PTN-03 implementation
- [c3-114 Design System](./c3-114-design-system.md) - Token source
- [c3-133 UI Patterns](./c3-133-ui-patterns.md) - Pattern behaviors
