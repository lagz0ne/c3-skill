---
id: c3-2
c3-version: 3
title: API Backend
type: container
parent: c3-0
summary: Server-side business logic, database operations, authentication, and real-time sync
---

# API Backend

The API Backend handles all server-side operations including database queries, business flow execution, authentication, and real-time data synchronization. Built with @pumped-fn/lite for dependency injection, it uses flows for business logic orchestration, services for domain operations, and queries for database access. Server functions are exposed to the frontend via TanStack Start's createServerFn.

## Overview

```mermaid
graph TD
    subgraph Foundation
        c3-201[Entry Point]
        c3-202[Scope & DI]
        c3-203[Database Layer]
        c3-204[Logger]
        c3-205[Middleware]
    end

    subgraph Auxiliary
        c3-211[Flow Patterns]
        c3-212[Query Patterns]
        c3-213[Real-time Sync]
    end

    subgraph Feature
        c3-221[PR Flows]
        c3-222[Invoice Flows]
        c3-223[Payment Flows]
        c3-224[Auth Flows]
        c3-225[Audit Flows]
    end

    %% Foundation relationships
    c3-201 --> c3-202
    c3-202 --> c3-203
    c3-202 --> c3-204

    %% Foundation to Auxiliary
    c3-203 --> c3-212
    c3-204 --> c3-211
    c3-205 --> c3-211

    %% Auxiliary to Feature
    c3-211 --> c3-221
    c3-211 --> c3-222
    c3-211 --> c3-223
    c3-211 --> c3-224
    c3-212 --> c3-221
    c3-212 --> c3-222
    c3-212 --> c3-223
    c3-213 --> c3-221
    c3-213 --> c3-222
    c3-213 --> c3-223
```

## Components

### Foundation
> Primitives others build on. High impact when changed. Reusable within this container.

| ID | Name | Status | Responsibility |
|----|------|--------|----------------|
| c3-201 | Entry Point | active | Server bootstrap, scope creation, signal handling, graceful shutdown |
| c3-202 | Scope & DI | active | @pumped-fn/lite scope management, dependency injection, context tags |
| c3-203 | Database Layer | active | Drizzle ORM setup, PostgreSQL connection, schema definitions, transactions |
| c3-204 | Logger | active | Pino logger configuration, structured logging, request correlation |
| c3-205 | Middleware | active | TanStack middleware for execution context, user authentication from cookies |

### Auxiliary
> Conventions for using external tools HERE. "This is how we use X in this project."

| ID | Name | Status | Responsibility |
|----|------|--------|----------------|
| c3-211 | Flow Patterns | active | @pumped-fn/lite flow definitions with Zod parsing, deps injection, context access |
| c3-212 | Query Patterns | active | Database query functions wrapped in service atoms, type-safe with generated types |
| c3-213 | Real-time Sync | active | WebSocket sync server, change event emission, delta/full sync messages |

### Feature
> Domain-specific. Uses Foundation + Auxiliary. Not reusable outside this context.

| ID | Name | Status | Responsibility |
|----|------|--------|----------------|
| c3-221 | PR Flows | active | Payment request CRUD, approval/unapproval, status transitions, invoice linking |
| c3-222 | Invoice Flows | active | Invoice listing, parsing, status updates, file attachment handling |
| c3-223 | Payment Flows | active | Payment method management, completion tracking |
| c3-224 | Auth Flows | active | Google OAuth flow, test token auth, session cookie management |
| c3-225 | Audit Flows | active | Audit log queries, security event tracking |

## Fulfillment

| Link (from c3-0) | Fulfilled By | Constraints |
|------------------|--------------|-------------|
| c3-1 -> c3-2 (Server Functions) | c3-205, c3-221, c3-222, c3-223 | All via createServerFn with middleware |
| c3-2 -> E1 (PostgreSQL) | c3-203, c3-212 | Transactions for multi-step operations |
| c3-2 -> E2 (Google OAuth) | c3-224 | OAuth2 token exchange |
| c3-2 -> E3 (OpenTelemetry) | c3-201, c3-204 | OTLP export configured at startup |

## Linkages

| From | To | Reasoning |
|------|-----|-----------|
| c3-201 | c3-202 | Entry creates root scope with extensions and tags |
| c3-202 | c3-203 | Scope resolves database connection atom |
| c3-205 | c3-211 | Middleware provides execution context to flows |
| c3-211 | c3-212 | Flows execute database queries via execContext |
| c3-211 | c3-213 | Flows emit change events after mutations |
| c3-221 | c3-213 | PR changes broadcast via WebSocket to connected clients |

## Testing

> Tests component <-> component linkages within this container.

### Integration Tests

| Scenario | Components Involved | Verifies |
|----------|---------------------|----------|
| PR Creation | c3-205, c3-221, c3-203 | Creates PR with approval steps in transaction |
| Approval Flow | c3-205, c3-221, c3-203 | Step progression, anyof/allof mode logic |
| Auth Cookie | c3-205, c3-224 | User lookup from cookie, permission loading |
| Sync Broadcast | c3-221, c3-213 | Changes emit to WebSocket clients |

### Mocking

| Dependency | How to Mock | When |
|------------|-------------|------|
| PostgreSQL | test-db.ts with test database | Integration tests |
| Google OAuth | Mock googleapis responses | Auth flow tests |
| WebSocket | Mock sync.emit | Flow unit tests |

### Fixtures

| Entity | Factory/Source | Notes |
|--------|----------------|-------|
| PR | apps/start/test/fixtures/pr.ts | Includes approval flow config |
| Invoice | apps/start/test/fixtures/invoice.ts | With services array |
| User | apps/start/test/fixtures/user.ts | Permissions array |
