---
id: c3-211
c3-version: 3
title: Flow Patterns
type: component
category: auxiliary
parent: c3-2
summary: Conventions for defining business logic flows using @pumped-fn/lite
---

# Flow Patterns

Establishes how business logic is structured using @pumped-fn/lite flows with Zod schema parsing, dependency injection, context-based execution, and consistent result types.

## Conventions

| Rule | Why |
|------|-----|
| Define flows with `flow({deps, parse, factory})` | Consistent structure for all business operations |
| Use Zod schema in `parse` | Input validation before execution |
| Namespace pattern for types | Group Input/Success/Failure/Result types together |
| Access current user via `ctx.data.seekTag(currentUserTag)` | Consistent auth context access |
| Return discriminated union results | Type-safe success/failure handling |
| Use `ctx.exec()` for service/query calls | Enables execution tracking and tracing |
| Emit sync events after mutations | Real-time updates to connected clients |
| Check executionId for sync acknowledgment | Prevents duplicate notifications |

## Applies To

| Component | Usage |
|-----------|-------|
| c3-221 PR Flows | approvePr, unapprovePr, requestApprovals, updatePr |
| c3-222 Invoice Flows | getInvoice, listInvoices |
| c3-223 Payment Flows | getPayment, listPayments |
| c3-224 Auth Flows | authenticateWithGoogle, authenticateWithTestToken |

## Testing

| Convention | How to Test |
|------------|-------------|
| Zod parsing | Pass invalid input, verify parse error |
| Missing user tag | Call without currentUserTag, verify USER_NOT_FOUND |
| Success result | Valid input and user, verify success: true |
| Failure result | Business rule violation, verify success: false with reason |
| Sync emission | Mutation flow, verify sync.emit called |

## References

- `apps/start/src/server/flows/` - All flow definitions
