---
id: c3-212
c3-version: 3
title: Query Patterns
type: component
category: auxiliary
parent: c3-2
summary: Conventions for database queries using Drizzle ORM wrapped in service atoms
---

# Query Patterns

Establishes how database queries are structured as service atoms with typed input/output, transaction support, and consistent error handling.

## Conventions

| Rule | Why |
|------|-----|
| Wrap queries in `service({deps, factory})` | Enables dependency injection and testing |
| Use Drizzle query builder | Type-safe SQL generation |
| Accept execContext as first parameter | Access transaction context when needed |
| Use generated types from types.ts | Consistent row types across queries |
| Support transactionTag for atomic operations | Multi-table operations in single transaction |
| Return null for not found (not throw) | Caller decides how to handle missing data |
| Use indexed columns in WHERE clauses | Performance for large datasets |

## Applies To

| Component | Usage |
|-----------|-------|
| prQueries | getPr, listPrs, newPr, updatePr |
| invoiceQueries | getInvoice, listInvoices |
| paymentQueries | getPayment, listPayments |
| approvalQueries | newApproval, newApprovalStep, getApprovalRecords |
| userQueries | getUser, getUserPermissions |

## Testing

| Convention | How to Test |
|------------|-------------|
| Type safety | Use wrong column name, verify compile error |
| Transaction support | Run in tx, rollback, verify no changes |
| Null returns | Query non-existent ID, verify null (not throw) |
| Index usage | EXPLAIN query, verify index scan |
| Generated types | Verify ListPrRow matches actual columns |

## References

- `apps/start/src/server/dbs/queries/` - All query modules
