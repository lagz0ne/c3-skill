---
id: c3-213
c3-version: 3
title: Real-time Sync
type: component
category: auxiliary
parent: c3-2
summary: Server-side WebSocket sync for broadcasting data changes to connected clients
---

# Real-time Sync

Establishes how the server broadcasts data changes to connected clients using WebSocket, supporting delta updates, full syncs, and execution acknowledgments.

## Conventions

| Rule | Why |
|------|-----|
| Use sync.emit() after mutations | Notify connected clients of changes |
| Include executionId when available | Client can filter own actions |
| Structure as ChangeEvent with entity/type/id/data | Consistent message format |
| Support delta messages for efficiency | Only changed data transmitted |
| Support full sync for reconnection | Client can recover state |
| Send ack messages for execution confirmation | Client knows server processed action |
| Filter PRs by user on sync | Users only see PRs they can access |

## Applies To

| Component | Usage |
|-----------|-------|
| c3-221 PR Flows | Emit PR changes after create/update/approve |
| c3-222 Invoice Flows | Emit invoice status changes |
| c3-223 Payment Flows | Emit payment updates |
| wsServer resource | WebSocket connection management |

## Testing

| Convention | How to Test |
|------------|-------------|
| Delta emission | Mutate, verify delta message sent |
| ExecutionId passthrough | Include ID, verify in outgoing message |
| Full sync content | Request full sync, verify all entities included |
| Client filtering | Connect as user, verify only accessible PRs |
| Connection cleanup | Disconnect client, verify no memory leak |

## References

- `apps/start/src/server/resources/sync.ts` - Sync types
- `apps/start/src/server/resources/wsServer.ts` - WebSocket server
